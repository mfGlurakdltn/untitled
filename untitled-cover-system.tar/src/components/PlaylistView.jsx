import React, { useState } from 'react';
import { ArrowLeft, Plus, X, Trash2, Edit2, List as ListIcon, Image } from 'lucide-react';
import TrackList from './TrackList';

function PlaylistView({ 
  playlists, 
  selectedPlaylist, 
  onPlaylistClick, 
  onBack,
  currentTrack,
  onTrackClick,
  onRemoveTrack,
  onDeletePlaylist,
  onRenamePlaylist,
  onUpdatePlaylistCover,
  showCreateModal,
  setShowCreateModal,
  newPlaylistName,
  setNewPlaylistName,
  onCreatePlaylist
}) {
  const [editingPlaylist, setEditingPlaylist] = useState(null);
  const [editName, setEditName] = useState('');

  const startEditing = (playlist) => {
    setEditingPlaylist(playlist.id);
    setEditName(playlist.name);
  };

  const saveEdit = () => {
    if (editName.trim()) {
      onRenamePlaylist(editingPlaylist, editName.trim());
      setEditingPlaylist(null);
      setEditName('');
    }
  };

  const cancelEdit = () => {
    setEditingPlaylist(null);
    setEditName('');
  };

  const handleCoverUpload = async (playlistId, file) => {
    if (file && file.type.startsWith('image/')) {
      await onUpdatePlaylistCover(playlistId, file);
    } else {
      alert('Please select a valid image file');
    }
  };

  // Playlist Overview
  if (!selectedPlaylist) {
    return (
      <>
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl mb-2">PLAYLISTS</h1>
            <p className="text-white/50 text-sm">{playlists.length} playlists</p>
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 border border-white/20 hover:bg-white/5 text-sm flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            NEW PLAYLIST
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {playlists.length === 0 ? (
            <p className="text-white/50 col-span-full text-center py-8">No playlists yet</p>
          ) : (
            playlists.map(playlist => (
              <div key={playlist.id} className="group">
                {editingPlaylist === playlist.id ? (
                  <div className="space-y-2 border border-white/10 p-4" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') saveEdit();
                        if (e.key === 'Escape') cancelEdit();
                      }}
                      className="w-full bg-white/5 border border-white/10 px-2 py-1 text-sm focus:outline-none focus:border-white/30"
                      autoFocus
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={saveEdit}
                        className="flex-1 px-2 py-1 bg-white/10 hover:bg-white/20 text-xs"
                      >
                        Save
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="flex-1 px-2 py-1 border border-white/10 hover:bg-white/5 text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="relative cursor-pointer" onClick={() => onPlaylistClick(playlist)}>
                      <div className="aspect-square bg-white/5 mb-3 overflow-hidden flex items-center justify-center border border-white/10 relative group">
                        {playlist.cover_url ? (
                          <img 
                            src={playlist.cover_url} 
                            alt={playlist.name}
                            className="w-full h-full object-cover group-hover:opacity-80 transition-opacity"
                          />
                        ) : (
                          <ListIcon className="w-12 h-12 text-white/20" />
                        )}
                        <label 
                          className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              if (e.target.files[0]) {
                                handleCoverUpload(playlist.id, e.target.files[0]);
                              }
                            }}
                          />
                          <div className="flex flex-col items-center gap-1">
                            <Image className="w-6 h-6" />
                            <span className="text-xs">Upload Cover</span>
                          </div>
                        </label>
                      </div>
                      <div className="text-sm font-medium truncate">{playlist.name}</div>
                      <div className="text-xs text-white/50">Playlist</div>
                    </div>
                    <div className="flex gap-1 mt-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          startEditing(playlist);
                        }}
                        className="flex-1 text-white/50 hover:text-white p-1 border border-white/10 hover:bg-white/5"
                        title="Rename playlist"
                      >
                        <Edit2 className="w-3 h-3 mx-auto" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Delete playlist "${playlist.name}"?`)) {
                            onDeletePlaylist(playlist.id);
                          }
                        }}
                        className="flex-1 text-white/50 hover:text-red-500 p-1 border border-white/10 hover:bg-white/5"
                        title="Delete playlist"
                      >
                        <Trash2 className="w-3 h-3 mx-auto" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))
          )}
        </div>

        {/* Create Playlist Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-black border border-white/20 w-full max-w-md p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl">NEW PLAYLIST</h2>
                <button onClick={() => setShowCreateModal(false)}>
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-white/50 mb-2">PLAYLIST NAME *</label>
                  <input
                    type="text"
                    value={newPlaylistName}
                    onChange={(e) => setNewPlaylistName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && newPlaylistName.trim()) {
                        onCreatePlaylist();
                      }
                    }}
                    className="w-full bg-white/5 border border-white/10 px-3 py-2 text-sm focus:outline-none focus:border-white/30"
                    placeholder="My Playlist"
                    autoFocus
                  />
                </div>
                <button
                  onClick={onCreatePlaylist}
                  className="w-full py-3 border border-white/20 hover:bg-white/5 text-sm"
                >
                  CREATE PLAYLIST
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  // Playlist Detail
  const playlistTracks = selectedPlaylist.tracks || [];
  
  return (
    <>
      <button 
        onClick={onBack}
        className="flex items-center gap-2 mb-6 text-white/70 hover:text-white"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Playlists
      </button>
      <div className="flex gap-6 mb-8">
        <div className="w-48 h-48 bg-white/5 flex-shrink-0 flex items-center justify-center border border-white/10 relative group">
          {selectedPlaylist.cover_url ? (
            <img 
              src={selectedPlaylist.cover_url} 
              alt={selectedPlaylist.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <ListIcon className="w-20 h-20 text-white/20" />
          )}
          <label 
            className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
          >
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                if (e.target.files[0]) {
                  handleCoverUpload(selectedPlaylist.id, e.target.files[0]);
                }
              }}
            />
            <div className="flex flex-col items-center gap-1">
              <Image className="w-6 h-6" />
              <span className="text-xs">Upload Cover</span>
            </div>
          </label>
        </div>
        <div className="flex flex-col justify-end">
          <p className="text-xs text-white/50 mb-2">PLAYLIST</p>
          <h1 className="text-4xl font-bold mb-4">{selectedPlaylist.name}</h1>
          <p className="text-sm text-white/50">{playlistTracks.length} tracks</p>
        </div>
      </div>
      <TrackList 
        tracks={playlistTracks.map(pt => pt.tracks)}
        currentTrack={currentTrack}
        onTrackClick={onTrackClick}
        onRemoveFromPlaylist={(track) => {
          const pt = playlistTracks.find(p => p.tracks.id === track.id);
          if (pt) onRemoveTrack(pt.id);
        }}
        showRemove={true}
      />
    </>
  );
}

export default PlaylistView;
